package it.nntdata.bank.contocorrente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContoCorrenteApplicationTests {

    @Test
    void contextLoads() {
    }

}
