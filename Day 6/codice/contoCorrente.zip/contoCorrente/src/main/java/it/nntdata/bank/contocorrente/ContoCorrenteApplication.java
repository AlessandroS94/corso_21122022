package it.nntdata.bank.contocorrente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContoCorrenteApplication {

    public static void main(String[] args) {
        SpringApplication.run(ContoCorrenteApplication.class, args);
    }

}
