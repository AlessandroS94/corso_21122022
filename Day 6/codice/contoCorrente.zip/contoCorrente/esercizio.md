## Esercizio

Realizzare un'applicazione che permetta di gestire il proprio conto corrente.
Si prevede la realizzazione delle seguenti funzionalità:
1. visualizza nome e cognome
2. visualizza balance
3. visualizza iban
4. invia bonifico
