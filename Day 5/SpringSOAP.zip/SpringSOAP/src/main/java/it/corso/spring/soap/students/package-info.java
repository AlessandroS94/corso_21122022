@javax.xml.bind.annotation.XmlSchema(namespace = "http://example.it/students", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package it.corso.spring.soap.students;
