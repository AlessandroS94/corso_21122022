## SPRING BOOT SOAP
Una volta startato il progetto potete ritrovare il file wsdl presso il seguente indirizzo

http://localhost:8085/ws/students.wsdl

Per testare l'applicativo si consiglia di scaricare https://www.soapui.org/downloads/thank-you-for-downloading-soapui/