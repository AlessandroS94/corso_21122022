package it.course.rest.examplecourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleCourseApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExampleCourseApplication.class, args);
    }

}
