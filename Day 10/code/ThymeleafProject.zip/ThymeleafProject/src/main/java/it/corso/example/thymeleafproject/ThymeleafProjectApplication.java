package it.corso.example.thymeleafproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThymeleafProjectApplication.class, args);
    }

}
