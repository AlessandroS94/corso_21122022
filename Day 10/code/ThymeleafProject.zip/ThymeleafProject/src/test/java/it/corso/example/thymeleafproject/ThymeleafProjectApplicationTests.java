package it.corso.example.thymeleafproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
