package it.academy.corso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataRestTests {

	@Test
	void contextLoads() {
	}

}
